public class SingletonPttern {
    private static SingletonPttern instance = null;
    private SingletonPttern(){}
    public static SingletonPttern getInstance(){
        if(instance==null) instance = new SingletonPttern();
        return instance;
    }
    public void log(String msg){ System.out.println("[Singleton Log] "+msg);}
}