
import com.sun.net.httpserver.HttpServer;
import java.net.InetSocketAddress;
import java.io.IOException;
import java.io.OutputStream;

public class Server {
    public static void main(String[] args) throws Exception {
        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);

        // Path + Handler object (inline HttpHandler stubs that you can replace to delegate to your controllers)
        server.createContext("/auth", exchange -> {
            String response = "Auth endpoint - not implemented";
            try {
                exchange.sendResponseHeaders(501, response.getBytes().length);
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(response.getBytes());
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }); // handles /auth/register, /auth/login, /auth/me

        server.createContext("/ads", exchange -> {
            String response = "Ads endpoint - not implemented";
            try {
                exchange.sendResponseHeaders(501, response.getBytes().length);
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(response.getBytes());
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }); // handles /ads GET & POST

        server.setExecutor(null); // default executor
        server.start();

        System.out.println("Server running at http://localhost:8080");
    }
}