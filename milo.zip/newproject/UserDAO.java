
import java.sql.*;
import java.util.*;



public class UserDAO {
    public static boolean create(String name, String email, String password, String role, String contact) {
        try {
            Connection con = DbConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("INSERT INTO users(name,email,password,role,contact) VALUES(?,?,?,?,?)");
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, password);
            ps.setString(4, role);
            ps.setString(5, contact);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public static Optional<User> findByEmail(String email) {
        try {
            Connection con = DbConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM users WHERE email=?");
            ps.setString(1,email);
            ResultSet rs = ps.executeQuery();
            if(rs.next()) {
                return Optional.of(new User(rs.getInt("id"),rs.getString("name"),rs.getString("email"),rs.getString("password"),rs.getString("role"),rs.getString("contact")));
    }
        } catch (SQLException e) { e.printStackTrace(); }
        return Optional.empty();
    }

    public static Optional<User> findById(int id) {
        try {
            Connection con = DbConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM users WHERE id=?");
            ps.setInt(1,id);
            ResultSet rs = ps.executeQuery();
            if(rs.next()) {
                return Optional.of(new User(rs.getInt("id"),rs.getString("name"),rs.getString("email"),rs.getString("password"),rs.getString("role"),rs.getString("contact")));
            }
        } catch (SQLException e) { e.printStackTrace(); }
    return Optional.empty();
}

}
