
    import java.sql.*;

public class DbConnection {
    private static Connection conn = null;

    public static Connection getConnection() throws SQLException {
        if (conn == null || conn.isClosed()) {
            String url = "jdbc:mysql://localhost:3306/service_booking";
            String user = "root";
            String pass = "YOUR_PASSWORD";
            conn = DriverManager.getConnection(url, user, pass);
        }
        return conn;
    }
}
    

