
    import java.security.*;

public class HashUtil {
    /**
     * @param str
     * @return
     */
    public static String sha256(String str) {
        try{
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(str.getBytes());
            StringBuilder sb = new StringBuilder();
            for(byte b:hash){ sb.append(String.format("%02x",b)); }
            return sb.toString();
        } catch(Exception e){ e.printStackTrace(); return str; }
    }
}

