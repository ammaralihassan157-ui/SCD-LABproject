
    import java.sql.*;
    import java.util.*;
    
    public class AdDAO {
        public static boolean create(int companyId, String title, String type, String price, String desc, String avail) {
            try {
                Connection con = DbConnection.getConnection();
                PreparedStatement ps = con.prepareStatement("INSERT INTO ads(company_id,title,service_type,price,description,availability) VALUES(?,?,?,?,?,?)");
                ps.setInt(1, companyId);
                ps.setString(2,title);
                ps.setString(3,type);
                ps.setString(4,price);
                ps.setString(5,desc);
                ps.setString(6,avail);
                return ps.executeUpdate() > 0;
            } catch(SQLException e){ e.printStackTrace(); return false;}
        }
    
        public static List<String> allJson(String q) {
            List<String> list = new ArrayList<>();
            try {
                Connection con = DbConnection.getConnection();
                String sql = "SELECT * FROM ads";
                if(q != null) sql += " WHERE title LIKE ?";
                PreparedStatement ps = con.prepareStatement(sql);
                if(q!=null) ps.setString(1,"%"+q+"%");
                ResultSet rs = ps.executeQuery();
                while(rs.next()) {
                    String json = String.format("{\"id\":%d,\"title\":\"%s\",\"companyId\":\"%d\"}",rs.getInt("id"),rs.getString("title"),rs.getInt("company_id"));
                    list.add(json);
                }
            } catch(SQLException e){ e.printStackTrace();}
            return list;
        }
    }


