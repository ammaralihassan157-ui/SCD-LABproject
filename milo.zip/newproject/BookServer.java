
    import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;

import java.io.*;
import java.net.InetSocketAddress;
import java.util.*;

public class BookServer {

    static class Book {
        String id;
        String title;
        String author;
        int year;

        Book(String id, String title, String author, int year) {
            this.id = id;
            this.title = title;
            this.author = author;
            this.year = year;
        }
    }

    static ArrayList<Book> books = new ArrayList<>();

    public static void main(String[] args) throws Exception {

        HttpServer server = HttpServer.create(new InetSocketAddress(8000), 0);

        server.createContext("/addBook", (exchange) -> {
            if (exchange.getRequestMethod().equalsIgnoreCase("POST")) {
                String body = new String(exchange.getRequestBody().readAllBytes());
                Map<String, String> data = parse(body);
                Book b = new Book(UUID.randomUUID().toString(),
                        data.get("title"),
                        data.get("author"),
                        Integer.parseInt(data.get("year")));

                books.add(b);

                send(exchange, "Book Added Successfully!");
            }
        });

        server.createContext("/books", (exchange) -> {
            if (exchange.getRequestMethod().equalsIgnoreCase("GET")) {
                StringBuilder json = new StringBuilder("[");
                for (Book b : books) {
                    json.append("{")
                            .append("\"id\":\"").append(b.id).append("\",")
                            .append("\"title\":\"").append(b.title).append("\",")
                            .append("\"author\":\"").append(b.author).append("\",")
                            .append("\"year\":").append(b.year)
                            .append("},");
                }
                if (books.size() > 0) json.deleteCharAt(json.length() - 1);
                json.append("]");

                send(exchange, json.toString());
            }
        });
 server.createContext("/deleteBook", (exchange) -> {
            if (exchange.getRequestMethod().equalsIgnoreCase("POST")) {
                String body = new String(exchange.getRequestBody().readAllBytes());
                Map<String, String> data = parse(body);

                books.removeIf(b -> b.id.equals(data.get("id")));

                send(exchange, "Book Deleted!");
            }
        });

        server.createContext("/updateBook", (exchange) -> {
            if (exchange.getRequestMethod().equalsIgnoreCase("POST")) {
                String body = new String(exchange.getRequestBody().readAllBytes());
                Map<String, String> data = parse(body);

                for (Book b : books) {
                    if (b.id.equals(data.get("id"))) {
                b.title = data.get("title");
                b.author = data.get("author");
                b.year = Integer.parseInt(data.get("year"));
            }
        }

        send(exchange, "Book Updated!");
    }
});

        System.out.println("Server Running at http://localhost:8000/");
        server.start();
    }

    // Helper: Parse x-www-form-urlencoded
    static Map<String, String> parse(String body) {
        Map<String, String> map = new HashMap<>();
        for (String pair : body.split("&")) {
            String[] parts = pair.split("=");
            map.put(parts[0], parts.length > 1 ? parts[1].replace("+", " ") : "");
        }
        return map;
    }

    static void send(HttpExchange exchange, String response) throws IOException {
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        exchange.sendResponseHeaders(200, response.length());
        OutputStream os = exchange.getResponseBody();
        os.write(response.getBytes());
        os.close();
    }
}

